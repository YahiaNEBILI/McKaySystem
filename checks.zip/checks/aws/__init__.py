"""AWS checkers.

Each module in this package implements one or more AWS-facing checkers and
registers a factory with :mod:`checks.registry`.
"""

