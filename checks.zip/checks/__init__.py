"""Checker package.

Checker modules register themselves in :mod:`checks.registry` at import time.
The runner imports this package and walks it to discover all checkers.
"""

